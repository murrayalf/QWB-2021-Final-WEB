var randtoken,orderid=0;
var paytype = 0;
function initbody(){
	
	//生成randkey
	if(get('rankkeyanzhu')){
		//var keyss = js.cookie('rankkeyanzhu');
		//$('#rankkeyanzhu').html(keyss);
		//if(keyss==''){
			$.get(js.getajaxurl('getrandkey','view',''),function(ss){
				if(ss){
					js.savecookie('rankkeyanzhu',ss);
					$('#rankkeyanzhu').html(ss);
				}
			});
		//}
	}
	
	
	if(!get('modeid'))return;
	$('#btnbuy').click(gotobuy);
	$('#btnyzm').click(getocode);
	$('#wanbtn').click(wancbtns);
	randtoken=js.getrandtoken();
	$.get(js.getajaxurl('initcode','view','',{randtoken:randtoken, modeid:$('#modeid').val()}),function(s){
		var d = js.decode(s);
		$('#mobile').val(d.mobile);
		orderid=d.orderid;
		if(d.time>0)getocodeding(d.time);
		if(orderid>0){
			showpay(orderid, d.mobile, '请继续您的订单，付款完成后');
		}
	});
}

function submitsite(o1){
	if(js.ajaxbool)return false;
	var d = {title:$('#sitename').val(),url:$('#siteurl').val(),email:$('#siteemail').val()}
	if(d.title==''){js.setmsg('站点名称不能为空');return;}
	if(d.url==''){js.setmsg('站点地址不能为空');return;}
	if(d.email==''){js.setmsg('邮箱不能为空');return;}
	if(!js.email(d.email)){js.setmsg('邮箱格式不正确');return;}
	js.setmsg('处理中...');
	js.ajaxbool=true;
	$.post(js.getajaxurl('savesite'),d, function(s){
		if(s=='success'){
			js.setmsg('提交成功，我们会尽快将OA编号发到您邮箱','green');
		}else{
			js.setmsg(s);
			js.ajaxbool=false;
		}
	});
}
function ismobile(){
	js.setmsg();
	var sjh = $('#mobile').val();
	if(isempt(sjh)){
		js.setmsg('手机号码不能为空');
		return false;
	}
	var partten = /^1[3,5,8,4,7,6,9]\d{9}$/;
    if(!partten.test(sjh)||sjh.length!=11){
		js.setmsg('手机号码格式不对');
		return false;
	}
	return sjh;
}
function gotobuy(){
	var sjh = ismobile();
	if(!sjh)return;
	var yzm = $('#yzminput').val();
	if(isempt(sjh)){
		js.setmsg('手机验证码不能为空');
		return false;
	}
	var o1 = get('btnbuy');
	if(yzm.length!=6 || isNaN(yzm)){
		js.setmsg('手机验证码格式不对');
		return false;
	}
	o1.disabled=true;
	js.setmsg('验证中...');
	var  d= {mobile:sjh,randtoken:randtoken,code:yzm};
	d.modeid=$('#modeid').val();
	d.orderid=orderid;
	d.price=$('#price').val();
	$.post(js.getajaxurl('yzhengcode'),d, function(s){
		var a = js.decode(s);
		if(a.msg!='success'){
			js.setmsg(a.msg);
			o1.disabled=false;
		}else{
			showpay(a.orderid, sjh, '验证成功');
		}
	});
}
function showpay(oid, sjh, sm){
	orderid = oid;
	$('#btnbuy').hide();
	get('yzminput').disabled=true;
	get('mobile').disabled=true;
	$('#btnyzm').hide();
	$('#codeimg').hide();
	$('#codeyzm').hide();
	$('#payviewss').hide();
	js.setmsg(''+sm+'，我们会将安装key发送到手机：'+sjh+'上，请扫描以下二维码付款，请您放心购买使用模块！', 'green');
	$('#payview').show();
	changezf(0);
}
function getocode(){
	var sjh = ismobile();
	if(!sjh)return;
	var code = get('codeyzm').value;
	if(!code){
		js.setmsg('请输入数字验证码');
		get('codeyzm').focus();
		return false;
	}
	js.setmsg('');
	var o1 = get('btnyzm');
	o1.value='获取中...';
	o1.disabled=true;
	var d = {mobile:sjh,randtoken:randtoken,codeyzm:code};
	d.modeid=$('#modeid').val();
	d.orderid=orderid;
	$.post(js.getajaxurl('getcode'),d, function(s){
		if(s!='success'){
			js.setmsg(s);
			alert(s);
			get('codeimg').src='mode/code.php?'+Math.random();
			get('codeyzm').value='';
			get('codeyzm').focus();
			o1.value='重新获取';
			o1.disabled=false;
		}else{
			getocodeding(300);
		}
	});
}
var getocodedingtime;
function getocodeding(oi){
	clearTimeout(getocodedingtime);
	var o1 = get('btnyzm');
	o1.disabled=true;
	o1.value='倒计时('+oi+')';
	if(oi<=0){
		o1.disabled=false;
		o1.value='重新获取';
		return;
	}else{
		getocodedingtime=setTimeout('getocodeding('+(oi-1)+')',1000);
	}
}

function changezf(lx){
	var narr = ['支付宝','微信'];
	var narrs = ['alipay','weixin'];
	paytype = lx;
	$('#paytype').html(narr[lx]);
	get('iconslx').src = 'images/pay/'+narrs[lx]+'.png?rnd='+Math.random()+'';
	get('aimg0').className='';
	get('aimg1').className='';
	get('aimg'+lx+'').className='a1';
	get('iconsimg').src=js.getajaxurl('getimgs','view','',{price:$('#price').val(),type:narrs[lx]});
}
function wancbtns(){
	alert('感谢您对我们系统的支持！\n\n我们会在10分钟内将安装key发送到您的手机上 !\n\n有任何问题可随时联系我们。');
	var d={orderid:orderid,randtoken:randtoken,paytype:paytype};
	$.post(js.getajaxurl('wancpay'),d, function(s){
		if(s=='success'){
			location.reload();
		}
	});
}

function huineirs(sid,o1,num){
	var val = $('#facontent').val();
	if(!val){
		js.setmsg('请输入回复内容','','huimsgla');
		return;
	}
	var d = {mid:sid,cont:val,isemail:0,wangzhi:'',num:num};
	if(get('isfaemail') && get('isfaemail').checked)d.isemail=1;
	if(get('wangzhi'))d.wangzhi=get('wangzhi').value;
	js.setmsg('处理中...','','huimsgla');
	o1.disabled=true;
	$.post(js.getajaxurl('huiinfor'),d, function(s){
		if(s=='success'){
			location.reload();
		}else{
			js.setmsg(s,'red','huimsgla');
			o1.disabled=false;
		}
	});
}
function huifula(k){
	get('facontent').value = '回复'+k+'楼：'+get('facontent').value;
	get('facontent').focus();
}