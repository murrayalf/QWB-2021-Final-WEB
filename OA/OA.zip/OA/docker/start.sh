#!/bin/sh
service mysql start && su ctf -c "java -jar ruoyi-admin.jar"