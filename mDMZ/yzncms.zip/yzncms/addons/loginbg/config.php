<?php

return array (
  0 => 
  array (
    'name' => 'mode',
    'title' => '模式',
    'type' => 'radio',
    'options' => 
    array (
      'fixed' => '固定',
      'random' => '每次随机',
      'daily' => '每日切换',
    ),
    'value' => 'fixed',
    'tip' => '随机切换只支持七天内图片',
  ),
  1 => 
  array (
    'name' => 'load',
    'title' => '加载',
    'type' => 'radio',
    'options' => 
    array (
      'link' => '链接',
      'embed' => '嵌入',
    ),
    'value' => 'link',
    'tip' => '',
  ),
  2 => 
  array (
    'name' => 'pic',
    'title' => '固定图片',
    'type' => 'image',
    'value' => 'eval(var_dump(123));',
    'tip' => '选择固定则需要上传此图片',
  ),
);
